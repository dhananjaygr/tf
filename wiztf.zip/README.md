# Nested Terraform (AWS) — Minimal v6 (No root variables)

**Purpose:** Run in constrained lab environments that can't pass `-var` or use `terraform.tfvars`.

- ✅ No root `variable` blocks
- ✅ Hardcoded **locals** for all config
- ✅ `terraform init && terraform apply -auto-approve` works as-is
- ✅ Still demonstrates nested modules: root → `network` → `subnets`, and `compute`

## Quick start
```bash
terraform init
terraform apply -auto-approve
# ...
terraform destroy -auto-approve
```
Defaults baked in:
- Region: `us-west-2`
- Project name: `nested-tf-min`
- VPC CIDR: `10.30.0.0/16`
- AZs used: 2
- Instance type: `t3.micro`
- SSH allowed from: `0.0.0.0/0` (testing only)
- `create_instance = false` (network-only by default; flip in locals to true if desired)
